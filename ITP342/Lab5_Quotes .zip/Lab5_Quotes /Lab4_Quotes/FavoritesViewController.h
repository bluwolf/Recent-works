//
//  FavoritesViewController.h
//  Lab3_Quotes
//
//  Created by Xiaohan Chen on 4/10/15.
//  Copyright (c) 2015 Xiaohan Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesViewController : UITableViewController

@end
