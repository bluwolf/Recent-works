//
//  AppDelegate.h
//  Lab2_CreateStory
//
//  Created by Xiaohan Chen on 2/2/15.
//  Copyright (c) 2015 Xiaohan Chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

